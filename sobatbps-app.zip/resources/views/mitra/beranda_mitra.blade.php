@extends('mitra.master_mitra')

@section('title')
    Beranda - SOBAT BPS
@endsection

@section('content')
<div class="content text-center mt-3">
    <h1>Halaman Beranda Mitra BPS</h1>
</div>
@endsection