@extends('admin.master_admin')

@section('title')
    Beranda - SOBAT BPS
@endsection

@section('content')
<div class="content text-center">
    <h1>Halaman Admin</h1>
</div>
@endsection