@extends('admin.master_admin')

@section('title')
    Penilaian Rekruitmen - SOBAT BPS
@endsection

@section('content')
<div class="container mt-3">
    <h3><u>PENILAIAN REKRUITMEN</u></h3>
    <a href="{{ url('/tambah-penilaian') }}" class="btn btn-success mb-3">Tambah Nilai</a>
    <table class="table table-bordered">
        <thead class="text-center">
            <tr>
                <th>Nik</th>
                <th>Nama</th>
                <th>Nilai C1</th>
                <th>Nilai C2</th>
                <th>Nilai C3</th>
                <th>Nilai C4</th>
                <th>Hasil Akhir</th>
                <th>Aksi</th>
            </tr>
        </thead>
        @foreach($penilaians as $penilaian)
        <tbody>
            <tr>
                <td>{{ $penilaian->survei->nik }}</td>
                <td>{{ $penilaian->survei->nama_lengkap }}</td>
                <td class="text-center">{{ number_format($penilaian->nilai_c1, 4) }}</td>
                <td class="text-center">{{ number_format($penilaian->nilai_c2, 4) }}</td>
                <td class="text-center">{{ number_format($penilaian->nilai_c3, 4) }}</td>
                <td class="text-center">{{ number_format($penilaian->nilai_c4, 4) }}</td>
                <td class="text-center">{{ number_format($penilaian->hasil_akhir, 4) }}</td>
                {{-- <td class="text-center">
                    <a href="{{ url('/penilaian-rekruitmen/edit/') }}/{{ $penilaian->id }}" class="btn btn-warning">Edit</a>
                    <a href="{{ url('/penilaian-rekruitmen') }}/{{ $penilaian->id }}" class="btn btn-danger">Hapus</a>
                </td> --}}
                <td class="text-center">
                    <form action="{{ url('/penilaian-rekruitmen',$penilaian->id) }}" method="POST">

                        <a class="btn btn-warning btn-sm" href="{{ url('/penilaian-rekruitmen/edit',$penilaian->id) }}">Edit</a>
    
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                    </form>
                </td>
            </tr>
        </tbody>
        @endforeach
    </table>
</div>
@endsection 