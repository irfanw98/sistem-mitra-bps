<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\{
    User,
    Survei,
    Penilaian
};

class AdminController extends Controller
{
    public function index()
    {
        return view('beranda_admin');
    }

    public function datapendaftar()
    {
        $surveis = Survei::latest()->get();
        
        return view('admin.data_pendaftar', compact('surveis'));
    }

    public function detailpendaftar($id)
    {
        $survei = Survei::findOrFail($id);

        return view('admin.detail_pendaftar', compact('survei'));
    }

    public function terimapendaftar($id)
    {
        $survei = Survei::findOrFail($id);
        $penilaian = Penilaian::where('survei_id', $id)->first();
        
        if(!$penilaian) {
            return "Mitra ini belum ada penilaian rekruitmen.";
        } 

        if($survei->id == $penilaian->survei_id)
        {

            if($survei->status == 0){
                $survei->status = 1;
                $survei->save();

                return redirect()->back();
            } else {
                return "Mitra sudah diterima.";
            }
        }
    }

    public function datapenilaian()
    {
        $penilaians = Penilaian::with('survei')->get();
        
        return view('admin.penilaian_rekruitmen', compact('penilaians'));
    }
    
    public function penilaiancreate()
    {
        $surveis = Survei::latest()->get();

        return view('admin.tambah_penilaian', compact('surveis'));
    }

    public function penilaian(Request $request)
    {
        // C1
        $pengalaman_c1 = floatval($request->input('pengalaman_c1'));
        $wawancara_c1 = floatval($request->input('wawancara_c1'));
        $soal_c1 = floatval($request->input('soal_c1'));
        
        $nilai_pangkat = 2;
        $pengalaman_centroid_c1 = $pengalaman_c1 - 0;
        $wawancara_centroid_c1  = $wawancara_c1 - 1;
        $soal_centroid_c1 = $soal_c1 - 0;

        $hasil_c1 =  sqrt((pow($pengalaman_centroid_c1, $nilai_pangkat)) + (pow($wawancara_centroid_c1, $nilai_pangkat)) + (pow($soal_centroid_c1, $nilai_pangkat))); 

        // C2
        $pengalaman_c2 = $request->input('pengalaman_c2');
        $wawancara_c2 = $request->input('wawancara_c2');
        $soal_c2 = $request->input('soal_c2');
        
        $pengalaman_centroid_c2 = $pengalaman_c2 - 0;
        $wawancara_centroid_c2  = $wawancara_c2 - 0;
        $soal_centroid_c2 = $soal_c2 - 1;

        $hasil_c2 =  sqrt((pow($pengalaman_centroid_c2, $nilai_pangkat)) + (pow($wawancara_centroid_c2, $nilai_pangkat)) + (pow($soal_centroid_c2, $nilai_pangkat))); 

        // C3
        $pengalaman_c3 = $request->input('pengalaman_c3');
        $wawancara_c3 = $request->input('wawancara_c3');
        $soal_c3 = $request->input('soal_c3');

        $pengalaman_centroid_c3 = $pengalaman_c3 - 1;
        $wawancara_centroid_c3  = $wawancara_c3 - 0;
        $soal_centroid_c3 = $soal_c3 - 0;

        $hasil_c3 =  sqrt((pow($pengalaman_centroid_c3, $nilai_pangkat)) + (pow($wawancara_centroid_c3, $nilai_pangkat)) + (pow($soal_centroid_c3, $nilai_pangkat)));
        
        // C4
        $pengalaman_c4 = $request->input('pengalaman_c4');
        $wawancara_c4 = $request->input('wawancara_c4');
        $soal_c4 = $request->input('soal_c4');

        $nilai_pangkat = 2;
        $pengalaman_centroid_c4 = $pengalaman_c4 - 0;
        $wawancara_centroid_c4  = $wawancara_c4 - 0;
        $soal_centroid_c4 = $soal_c4 - 1;

        $hasil_c4 =  sqrt((pow($pengalaman_centroid_c4, $nilai_pangkat)) + (pow($wawancara_centroid_c4, $nilai_pangkat)) + (pow($soal_centroid_c4, $nilai_pangkat)));

        //Hasil Akhir
        $hasil_akhir = min($hasil_c1, $hasil_c2, $hasil_c3, $hasil_c4);

        //create penilaian
        $penilaian = new Penilaian;
        $penilaian->survei_id = $request->survei_id;
        $penilaian->pengalaman_c1 = floatval($request->input('pengalaman_c1'));
        $penilaian->wawancara_c1 = floatval($request->input('wawancara_c1'));
        $penilaian->soal_c1 = floatval($request->input('soal_c1'));
        $penilaian->nilai_c1 = $hasil_c1;
        $penilaian->pengalaman_c2 = floatval($request->input('pengalaman_c2'));
        $penilaian->wawancara_c2 = floatval($request->input('wawancara_c2'));
        $penilaian->soal_c2 = floatval($request->input('soal_c2'));
        $penilaian->nilai_c2 = $hasil_c2;
        $penilaian->pengalaman_c3 = floatval($request->input('pengalaman_c3'));
        $penilaian->wawancara_c3 = floatval($request->input('wawancara_c3'));
        $penilaian->soal_c3 = floatval($request->input('soal_c3'));
        $penilaian->nilai_c3 = $hasil_c3;
        $penilaian->pengalaman_c4 = floatval($request->input('pengalaman_c4'));
        $penilaian->wawancara_c4 = floatval($request->input('wawancara_c4'));
        $penilaian->soal_c4 = floatval($request->input('soal_c4'));
        $penilaian->nilai_c4 = $hasil_c4;
        $penilaian->hasil_akhir = $hasil_akhir;
        $penilaian->save();

        return redirect('/penilaian-rekruitmen');
    }

    public function editpenilaian($id)
    {
        $penilaian = Penilaian::findOrFail($id);
        $surveis = Survei::get();
        
        return view('admin.edit_penilaian', compact('penilaian', 'surveis'));
    }

    public function updatepenilaian(Request $request, $id)
    {
        // C1
        $pengalaman_c1 = floatval($request->input('pengalaman_c1'));
        $wawancara_c1 = floatval($request->input('wawancara_c1'));
        $soal_c1 = floatval($request->input('soal_c1'));
        
        $nilai_pangkat = 2;
        $pengalaman_centroid_c1 = $pengalaman_c1 - 0;
        $wawancara_centroid_c1  = $wawancara_c1 - 1;
        $soal_centroid_c1 = $soal_c1 - 0;

        $hasil_c1 =  sqrt((pow($pengalaman_centroid_c1, $nilai_pangkat)) + (pow($wawancara_centroid_c1, $nilai_pangkat)) + (pow($soal_centroid_c1, $nilai_pangkat))); 


        // C2
        $pengalaman_c2 = $request->input('pengalaman_c2');
        $wawancara_c2 = $request->input('wawancara_c2');
        $soal_c2 = $request->input('soal_c2');
        
        $pengalaman_centroid_c2 = $pengalaman_c2 - 0;
        $wawancara_centroid_c2  = $wawancara_c2 - 0;
        $soal_centroid_c2 = $soal_c2 - 1;

        $hasil_c2 =  sqrt((pow($pengalaman_centroid_c2, $nilai_pangkat)) + (pow($wawancara_centroid_c2, $nilai_pangkat)) + (pow($soal_centroid_c2, $nilai_pangkat))); 

        // C3
        $pengalaman_c3 = $request->input('pengalaman_c3');
        $wawancara_c3 = $request->input('wawancara_c3');
        $soal_c3 = $request->input('soal_c3');

        $pengalaman_centroid_c3 = $pengalaman_c3 - 1;
        $wawancara_centroid_c3  = $wawancara_c3 - 0;
        $soal_centroid_c3 = $soal_c3 - 0;

        $hasil_c3 =  sqrt((pow($pengalaman_centroid_c3, $nilai_pangkat)) + (pow($wawancara_centroid_c3, $nilai_pangkat)) + (pow($soal_centroid_c3, $nilai_pangkat)));

        // C4
        $pengalaman_c4 = $request->input('pengalaman_c4');
        $wawancara_c4 = $request->input('wawancara_c4');
        $soal_c4 = $request->input('soal_c4');

        $nilai_pangkat = 2;
        $pengalaman_centroid_c4 = $pengalaman_c4 - 0;
        $wawancara_centroid_c4  = $wawancara_c4 - 0;
        $soal_centroid_c4 = $soal_c4 - 1;

        $hasil_c4 =  sqrt((pow($pengalaman_centroid_c4, $nilai_pangkat)) + (pow($wawancara_centroid_c4, $nilai_pangkat)) + (pow($soal_centroid_c4, $nilai_pangkat)));

        //Hasil Akhir
        $hasil_akhir = min($hasil_c1, $hasil_c2, $hasil_c3, $hasil_c4);

        $penilaian = Penilaian::findOrFail($id);
        $penilaian->survei_id = $request->survei_id;
        $penilaian->pengalaman_c1 = floatval($request->input('pengalaman_c1'));
        $penilaian->wawancara_c1 = floatval($request->input('wawancara_c1'));
        $penilaian->soal_c1 = floatval($request->input('soal_c1'));
        $penilaian->nilai_c1 = $hasil_c1;
        $penilaian->pengalaman_c2 = floatval($request->input('pengalaman_c2'));
        $penilaian->wawancara_c2 = floatval($request->input('wawancara_c2'));
        $penilaian->soal_c2 = floatval($request->input('soal_c2'));
        $penilaian->nilai_c2 = $hasil_c2;
        $penilaian->pengalaman_c3 = floatval($request->input('pengalaman_c3'));
        $penilaian->wawancara_c3 = floatval($request->input('wawancara_c3'));
        $penilaian->soal_c3 = floatval($request->input('soal_c3'));
        $penilaian->nilai_c3 = $hasil_c3;
        $penilaian->pengalaman_c4 = floatval($request->input('pengalaman_c4'));
        $penilaian->wawancara_c4 = floatval($request->input('wawancara_c4'));
        $penilaian->soal_c4 = floatval($request->input('soal_c4'));
        $penilaian->nilai_c4 = $hasil_c4;
        $penilaian->hasil_akhir = $hasil_akhir;
        $penilaian->save();


        return redirect('/penilaian-rekruitmen');
    }

    public function hapuspenilaian($id)
    {
        $penilaian = Penilaian::findOrfail($id);
        $survei = Survei::where('id', $penilaian->survei_id)->first();
        
        $penilaian->delete();
        $survei->delete();

        return redirect()->back();
    }


}
