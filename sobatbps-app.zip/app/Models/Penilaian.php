<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Survei;

class Penilaian extends Model
{
    use HasFactory;

    protected $table = 'penilaian';
    protected $guarded = ['id'];

    public function survei()
    {
        return $this->belongsTo(Survei::class, 'survei_id', 'id');
    }
}
