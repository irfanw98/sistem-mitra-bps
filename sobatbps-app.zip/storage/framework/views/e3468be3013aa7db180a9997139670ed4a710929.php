

<?php $__env->startSection('content'); ?>
<div class="card mx-auto" style="width: 32rem;">
    <main class="form-register">
        <form action="<?php echo e(url('/registrasi-admin')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="text-center">
                <img class="mb-4" src="<?php echo e(asset('img/logo.png')); ?>" alt="logo" width="80" height="70">
            </div>
            <div class="mb-2">
                <label for="nik" class="form-label">Nik</label>
                <input type="nik" class="form-control" name="nik" id="nik" required>
            </div>
            <div class="mb-2">
                <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
                <input type="nama_lengkap" class="form-control" name="nama_lengkap" id="nama_lengkap" required>
            </div>
            <div class="mb-2">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" name="email" id="email" required>
            </div>
            <div class="mb-2">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" name="password" id="password" required>
            </div>
            <button class="w-100 btn btn-lg btn-primary" type="submit">Register</button>
            <div class="mt-3 mb-3 text-center">
                <p>
                    Sudah punya akun ?
                    <a href="<?php echo e(url('/')); ?>">Login di sini</a>
                </p>
            </div>
        </form>
    </main>
</div> 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sobatbps-app\resources\views/register_admin.blade.php ENDPATH**/ ?>