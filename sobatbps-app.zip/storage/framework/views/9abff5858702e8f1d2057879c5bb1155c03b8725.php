

<?php $__env->startSection('title'); ?>
    Detail Riwayat - SOBAT BPS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    <h3><u>DETAIL RIWAYAT</u></h3>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th width="20%">Nik</th>
                <td><?php echo e($survei->nik); ?></td>
            </tr>
            <tr>
                <th>Nama Lengkap</th>
                <td><?php echo e($survei->nama_lengkap); ?></td>
            </tr>
            <tr>
                <th>Alamat</th>
                <td><?php echo e($survei->alamat); ?></td>
            </tr>
            <tr>
                <th>Tempat Lahir</th>
                <td><?php echo e($survei->tempat_lahir); ?></td>
            </tr>
            <tr>
                <th>Tanggal Lahir</th>
                <td><?php echo e($survei->tanggal_lahir); ?></td>
            </tr>
            <tr>
                <th>Alamat Email</th>
                <td><?php echo e($survei->email); ?></td>
            </tr>
            <tr>
                <th>Nomor Hp</th>
                <td><?php echo e($survei->nomor_hp); ?></td>
            </tr>
            <tr>
                <th>Jenis Kelamin</th>
                <td>
                    <?php echo e($survei->jenis_kelamin == 'L' ? 'Laki - Laki' : 'Perempuan'); ?>

                </td>
            </tr>
            <tr>
                <th>Umur</th>
                <td><?php echo e($survei->umur); ?></td>
            </tr>
            <tr>
                <th>Pengalaman Survei</th>
                <td>
                    <?php
                        $pengalaman_surveis = json_decode($survei->pengalaman_survei)
                    ?>
                    <?php $__currentLoopData = $pengalaman_surveis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengalaman_survei): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($pengalaman_survei == 'sensus_ekonomi'): ?>
                            <span>Sensus Ekonomi</span>, 
                        <?php elseif($pengalaman_survei == 'sensus_penduduk'): ?>
                            <span>Sensus Penduduk</span>,
                        <?php elseif($pengalaman_survei == 'sensus_pertanian'): ?>
                            <span>Sensus Pertanian</span>,
                        <?php elseif($pengalaman_survei == 'survei_lainnya'): ?>
                            <span>Survei Lainnya</span>,
                        <?php elseif($pengalaman_survei == 'belum_pernah'): ?>
                            <span>Belum Pernah</span>,
                        <?php elseif($pengalaman_survei == 'susenas'): ?>
                            <span>Susenas</span>,
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
            <tr>
                <th>Pendidikan</th>
                <td><?php echo e($survei->pendidikan); ?></td>
            </tr>
            <tr>
                <th>Status Perkawinan</th>
                <td>
                    <?php if($survei->status_perkawinan == 'belum_kawin'): ?>
                        <span>Belum Kawin</span>
                    <?php elseif($survei->status_perkawinan == 'cerai_hidup'): ?>
                        <span>Cerai Hidup</span>
                    <?php elseif($survei->status_perkawinan == 'cerai_mati'): ?>
                        <span>Cerai Mati</span>
                    <?php elseif($survei->status_perkawinan == 'kawin'): ?>
                        <span>Kawin</span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Status</th>
                <td><?php echo e($survei->status == 0 ? 'Diproses' : 'Diterima'); ?></td>
            </tr>
        </thead>
    </table>
    <table class="table table-bordered text-center"> 
        <thead>
            <tr>
                <th width="50%">Memiliki</th>
                <th width="50%">Menggunakan</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $memiliki_fasilitas = json_decode($survei->memiliki_fasilitas)
            ?>
            <?php $__currentLoopData = $memiliki_fasilitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memiliki_fasilitas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php if($memiliki_fasilitas == 'motor'): ?>
                        <span>Motor</span>
                        <td><?php echo e($survei->menggunakan_motor); ?></td>
                    <?php elseif($memiliki_fasilitas == 'hp_android'): ?>
                        <span>Hp Android</span>
                        <td><?php echo e($survei->menggunakan_hp); ?></td>
                    <?php elseif($memiliki_fasilitas == 'laptop'): ?>
                        <span>Laptop</span>
                        <td><?php echo e($survei->menggunakan_laptop); ?></td>
                    <?php elseif($memiliki_fasilitas == 'pc'): ?>
                        <span>Pc</span>
                        <td><?php echo e($survei->menggunakan_pc); ?></td>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mitra.master_mitra', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sobatbps-app\resources\views/mitra/detail_riwayat.blade.php ENDPATH**/ ?>