

<?php $__env->startSection('title'); ?>
    Data Pendaftar - SOBAT BPS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    <h3><u>DATA PENDAFTAR</u></h3>
    <table class="table table-bordered">
        <thead class="text-center">
            <tr>
                <th>Nik</th>
                <th>Nama</th>
                <th>Alamat Email</th>
                <th>Nomor Hp</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $surveis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survei): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($survei->nik); ?></td>
                <td><?php echo e($survei->nama_lengkap); ?></td>
                <td><?php echo e($survei->email); ?></td>
                <td><?php echo e($survei->nomor_hp); ?></td>
                <td class="text-center"><?php echo e($survei->status == 0 ? 'Diproses' : 'Diterima'); ?></td>
                <td class="text-center">
                    <form action="<?php echo e(url('/data-pendaftar',$survei->id)); ?>" method="POST">

                        <a class="btn btn-primary btn-sm" href="<?php echo e(url('/data-pendaftar',$survei->id)); ?>">Detail</a>
    
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <button type="submit" class="btn btn-success btn-sm" onclick="return confirm('Terima Proses?')">Terima</button>
                    </form>
                </td>
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sobatbps-app\resources\views/admin/data_pendaftar.blade.php ENDPATH**/ ?>