

<?php $__env->startSection('content'); ?>
    <div class="card mx-auto p-2" style="width: 24rem;">
        <main class="form-signin">
            <form action="<?php echo e(url('/login')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="text-center">
                    <img class="mb-4" src="<?php echo e(asset('img/logo.png')); ?>" alt="logo" width="80" height="70">
                    
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" id="email" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" id="password" required>
                </div>
                <button class="w-100 btn btn-lg btn-primary" type="submit">Login</button>
                <div class="mt-3 mb-3 text-center">
                    <p>Belum punya akun ? 
                        <a href="<?php echo e(url('/registrasi-mitra')); ?>">Register di sini</a>
                    </p>
                </div>
            </form>
        </main>
    </div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sobatbps-app\resources\views/login.blade.php ENDPATH**/ ?>