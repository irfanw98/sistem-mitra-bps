

<?php $__env->startSection('content'); ?>
    <h1>Halaman Home</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sobatbps-app\resources\views/home.blade.php ENDPATH**/ ?>