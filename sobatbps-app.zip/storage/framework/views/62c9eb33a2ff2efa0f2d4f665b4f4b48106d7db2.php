

<?php $__env->startSection('title'); ?>
    Beranda - SOBAT BPS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content text-center mt-3">
    <h1>Halaman Beranda Mitra BPS</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mitra.master_mitra', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sobatbps-app\resources\views/mitra/beranda_mitra.blade.php ENDPATH**/ ?>