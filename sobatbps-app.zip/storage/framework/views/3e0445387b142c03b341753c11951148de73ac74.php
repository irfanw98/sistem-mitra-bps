

<?php $__env->startSection('title'); ?>
    Penilaian Rekruitmen - SOBAT BPS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    <h3><u>PENILAIAN REKRUITMEN</u></h3>
    <a href="<?php echo e(url('/tambah-penilaian')); ?>" class="btn btn-success mb-3">Tambah Nilai</a>
    <table class="table table-bordered">
        <thead class="text-center">
            <tr>
                <th>Nik</th>
                <th>Nama</th>
                <th>Nilai C1</th>
                <th>Nilai C2</th>
                <th>Nilai C3</th>
                <th>Nilai C4</th>
                <th>Hasil Akhir</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $penilaians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penilaian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($penilaian->survei->nik); ?></td>
                <td><?php echo e($penilaian->survei->nama_lengkap); ?></td>
                <td class="text-center"><?php echo e(number_format($penilaian->nilai_c1, 4)); ?></td>
                <td class="text-center"><?php echo e(number_format($penilaian->nilai_c2, 4)); ?></td>
                <td class="text-center"><?php echo e(number_format($penilaian->nilai_c3, 4)); ?></td>
                <td class="text-center"><?php echo e(number_format($penilaian->nilai_c4, 4)); ?></td>
                <td class="text-center"><?php echo e(number_format($penilaian->hasil_akhir, 4)); ?></td>
                
                <td class="text-center">
                    <form action="<?php echo e(url('/penilaian-rekruitmen',$penilaian->id)); ?>" method="POST">

                        <a class="btn btn-warning btn-sm" href="<?php echo e(url('/penilaian-rekruitmen/edit',$penilaian->id)); ?>">Edit</a>
    
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                    </form>
                </td>
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sobatbps-app\resources\views/admin/penilaian_rekruitmen.blade.php ENDPATH**/ ?>