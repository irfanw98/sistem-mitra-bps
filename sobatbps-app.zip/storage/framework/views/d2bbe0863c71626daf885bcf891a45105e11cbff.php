

<?php $__env->startSection('title'); ?>
    Beranda - SOBAT BPS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content text-center">
    <h1>Halaman Admin</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sobatbps-app\resources\views/beranda_admin.blade.php ENDPATH**/ ?>